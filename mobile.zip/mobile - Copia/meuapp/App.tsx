import React, { useState } from "react";
import { Image, TouchableOpacity } from "react-native";

import Login from "./src/pages/login";
import RedefinirSenha from "./src/pages/redefinir senha";

export default function App() {
  const [pagina, setPagina] = useState("login");

  // TELA EXPLORER
  if (pagina === "explorer") {
    return (
      <TouchableOpacity
        style={{
          flex: 1,
          width: "100%",
          height: "100%",
        }}
        activeOpacity={1}
        onPress={() => setPagina("login")}
      >
        <Image
          source={{
            uri: "https://i.pinimg.com/736x/ff/75/22/ff752245ae648959603e8beefe9d1a50.jpg",
          }}
          style={{
            width: "100%",
            height: "100%",
          }}
          resizeMode="cover"
        />
      </TouchableOpacity>
    );
  }

  // TELA REDEFINIR SENHA
  if (pagina === "forgotPassword") {
    return (
      <RedefinirSenha
        voltar={() => setPagina("login")}
      />
    );
  }

  // TELA LOGIN
  return (
    <Login
      entrar={() => setPagina("explorer")}
      esqueciSenha={() => setPagina("forgotPassword")}
    />
  );
}